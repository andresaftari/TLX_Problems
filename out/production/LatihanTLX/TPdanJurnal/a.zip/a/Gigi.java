package a;

public class Gigi {
    private String nomor, nama, jenis;

    public Gigi(String nomor, String nama, String jenis) {
        this.nomor = nomor;
        this.nama = nama;
        this.jenis = jenis;
    }

    public String getNomor() {
        return nomor;
    }
}