package a;

public class Umum {
    private String nomor, nama, jenis;

    public Umum(String nomor, String nama, String jenis) {
        this.nomor = nomor;
        this.nama = nama;
        this.jenis = jenis;
    }

    public String getNomor() {
        return nomor;
    }
}
