package jurnal.no2;

import java.util.LinkedList;
import java.util.Queue;

public class Main {
    Queue<Roti> antrian = new LinkedList<>();

    public static void main(String[] args) {
        Main roti = new Main();

        roti.ambilNomor(1, "Roti Upin", "roti manis", 10);
        roti.ambilNomor(2, "Roti Ipin", "roti manis", 5);
        roti.ambilNomor(3, "Roti Ismail", "roti manis", 4);
        roti.panggilanRoti();
        roti.ambilNomor(4,"Roti Santi","roti asin",2);
    }

    private void ambilNomor(int nomor, String nama, String jenis, int jumlah) {
        int waiting = antrian.size();

        antrian.add(new Roti(nomor, nama, jenis, jumlah));
        if (waiting > 0) System.out.println("Anda menunggu " + waiting + " orang lagi");
    }

    private void panggilanRoti() {
        if (!antrian.isEmpty()) {
            System.out.println("Nomor " +
                    antrian.peek().getNoPanggilan() + " : pembelian " +
                    antrian.peek().getNama() + " sudah siap"
            );
            antrian.poll();
        }
    }
}
